
public class JavaApplication1 {
    public static void main(String[] args){
        System.out.println("Hello World");
        
        MainFrame myFrame = new MainFrame();
        myFrame.initialize();
                
    }
    
}
